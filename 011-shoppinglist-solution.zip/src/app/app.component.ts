import { Component, OnInit } from '@angular/core';
import { Item } from 'src/models/item';
import { ShoppingItem } from 'src/models/shopping-item';
import { initialItems } from 'src/models/item';
import { registerLocaleData } from '@angular/common';
import localeDe from '@angular/common/locales/de';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  items: Item[] = initialItems;
  shoppingItems: ShoppingItem[] = [];
  enterItem = false;
  newItem: Item = { name: '', price: 0 };
  selectedItem: Item = this.items[0];
  selectedAmount = 0;
  budget = 0;

  ngOnInit(): void {
    registerLocaleData(localeDe, 'de');
  }

  addProduct(): void {
    console.log(
      `addProduct(): name = ${this.newItem.name}, price = ${this.newItem.price}`
    );
    const item: Item = {
      name: this.newItem.name,
      price: this.newItem.price,
    };
    this.items.push(item);
    this.newItem.name = '';
    this.newItem.price = 0;
    this.enterItem = false;
  }

  addItem(): void {
    console.log(
      `addItem(): item = ${JSON.stringify(this.selectedItem)}, amount = ${
        this.selectedAmount
      }`
    );
    const item: ShoppingItem = {
      item: this.selectedItem,
      amount: this.selectedAmount,
      discount: false,
    };
    this.shoppingItems.push(item);
  }

  isValidProductInput(): boolean {
    return (
      this.newItem.name === '' ||
      this.newItem.price <= 0 ||
      this.newItem.price === null
    );
  }

  isValidAmount(): boolean {
    return this.selectedAmount <= 0 || this.selectedAmount === null;
  }

  calculateSum(): number {
    const sum = this.shoppingItems.reduce(
      (prev, next) => prev + next.item.price * next.amount,
      0
    );
    console.log(`calculateSum(): sum = ${sum}`);
    return sum;
  }

  checkBudget(): string {
    return this.budget != null && this.calculateSum() <= this.budget
      ? 'ok'
      : 'error';
  }

  removeItem(index: number): void {
    console.log(`removeItem(): index = ${index}`);
    this.shoppingItems.splice(index, 1);
  }
}
