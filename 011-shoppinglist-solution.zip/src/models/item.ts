export interface Item {
  name: string;
  price: number;
}

export const initialItems = [
  {
    name: 'Brot',
    price: 1.2,
  },
  {
    name: 'Milch',
    price: 0.9,
  },
  {
    name: 'Zucker',
    price: 1.5,
  },
];
