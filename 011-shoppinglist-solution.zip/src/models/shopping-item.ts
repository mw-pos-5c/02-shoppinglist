import { Item } from './item';

export interface ShoppingItem {
  item: Item;
  amount: number;
  discount: boolean;
}
